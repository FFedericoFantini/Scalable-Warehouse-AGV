import time
import math
from Path_Generation.path_generator import get_position_at


def is_position_safe(sim, agv_handle, new_pos, other_agvs, min_dist=0.8, lock=None):
    """
    Check whether a candidate AGV position is at a safe distance
    from all other AGVs.

    Parameters:
    - sim: CoppeliaSim API handle
    - agv_handle: handle of the current AGV
    - new_pos: proposed position [x, y, z]
    - other_agvs: list of all AGV handles
    - min_dist: minimum allowed distance between AGVs (meters)
    - lock: optional threading.Lock to protect sim API calls
    """
    for other in other_agvs:
        # Skip self-comparison
        if other == agv_handle:
            continue

        # Read other AGV position safely
        if lock:
            with lock:
                pos = sim.getObjectPosition(other, -1)
        else:
            pos = sim.getObjectPosition(other, -1)

        # Compute squared planar distance
        dx = pos[0] - new_pos[0]
        dy = pos[1] - new_pos[1]

        # Unsafe if distance is below threshold
        if (dx * dx + dy * dy) < (min_dist * min_dist):
            return False

    return True


def move_agv_along_path(
    sim,
    agv_handle,
    path,
    speed=0.5,
    z_offset=0.10,
    lock=None,
    all_agvs=None,
    min_dist=0.8
):
    """
    Move an AGV along a predefined path using time-based interpolation.

    Parameters:
    - sim: CoppeliaSim API handle
    - agv_handle: handle of the AGV to move
    - path: list of [x, y] waypoints
    - speed: linear speed in meters per second
    - z_offset: constant height above the floor
    - lock: optional threading.Lock to protect sim API calls
    - all_agvs: list of all AGV handles (for collision avoidance)
    - min_dist: minimum allowed distance between AGVs
    """

    # Trivial path: nothing to do
    if len(path) < 2:
        return True  # Path already completed

    # 1) Compute total path length
    total_dist = 0.0
    for i in range(len(path) - 1):
        x1, y1 = path[i]
        x2, y2 = path[i + 1]
        total_dist += math.hypot(x2 - x1, y2 - y1)

    # Degenerate path or invalid speed
    if total_dist < 1e-4 or speed <= 0:
        return True

    # Total traversal time
    total_time = total_dist / speed
    start_time = time.time()

    while True:
        elapsed = time.time() - start_time
        t = elapsed / total_time

        # Destination reached
        if t >= 1.0:
            x, y = path[-1]
            if lock:
                with lock:
                    sim.setObjectPosition(agv_handle, -1, [x, y, z_offset])
            else:
                sim.setObjectPosition(agv_handle, -1, [x, y, z_offset])
            return True  # Motion completed successfully

        # Interpolated position along the path
        x, y = get_position_at(path, t)
        new_pos = [x, y, z_offset]

        # Check collision safety before moving
        if all_agvs is None or is_position_safe(
            sim,
            agv_handle,
            new_pos,
            all_agvs,
            min_dist=min_dist,
            lock=lock
        ):
            # Safe to move
            if lock:
                with lock:
                    sim.setObjectPosition(agv_handle, -1, new_pos)
            else:
                sim.setObjectPosition(agv_handle, -1, new_pos)
        else:
            # Too close to another AGV:
            # wait briefly and compensate time to preserve motion continuity
            wait_time = 0.05
            time.sleep(wait_time)
            start_time += wait_time  # Key trick: pauses motion without slowing it down overall
            continue

        # Control loop at ~50 Hz
        time.sleep(0.02)
