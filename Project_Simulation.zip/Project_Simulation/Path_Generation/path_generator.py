# path_generator.py

import numpy as np


def generate_path_from_waypoints(nodes_sequence, step=0.05):
    """
    Generate a continuous 2D path from an ordered list of waypoints.
    The z-coordinate (if present) is ignored.

    Parameters
    ----------
    nodes_sequence : list
        Ordered list of waypoints.
        Each element can be:
        - a node object with a `.pos = (x, y, z)` attribute, or
        - a raw coordinate tuple/list (x, y) or (x, y, z)
    step : float
        Desired distance between consecutive interpolated path points (meters).

    Returns
    -------
    path : list of [x, y]
        Interpolated 2D path suitable for continuous motion.
    """

    # Convert all inputs into a list of 2D coordinates [x, y]
    xy_points = []
    for p in nodes_sequence:
        if hasattr(p, "pos"):   # Case: warehouse node object
            xy_points.append([p.pos[0], p.pos[1]])
        else:                   # Case: raw coordinate tuple/list
            xy_points.append([p[0], p[1]])

    # At least two waypoints are required to define a path
    if len(xy_points) < 2:
        raise ValueError("At least 2 waypoints are required to generate a path.")

    path = []

    # Perform linear interpolation segment by segment
    for i in range(len(xy_points) - 1):
        p1 = np.array(xy_points[i])
        p2 = np.array(xy_points[i + 1])

        # Vector and length of the current segment
        segment = p2 - p1
        dist = np.linalg.norm(segment)

        # Number of interpolation points for this segment
        n_points = max(int(dist / step), 1)

        for j in range(n_points):
            t = j / n_points  # Local interpolation parameter [0, 1)
            point = p1 * (1 - t) + p2 * t
            path.append(point.tolist())

    # Explicitly add the final waypoint
    path.append(xy_points[-1])

    return path


def get_position_at(path, t):
    """
    Compute the interpolated (x, y) position along a path.

    Parameters
    ----------
    path : list of [x, y]
        Discrete path points.
    t : float
        Normalized parameter in the range [0, 1],
        where 0 corresponds to the start of the path
        and 1 corresponds to the end.

    Returns
    -------
    position : [x, y]
        Interpolated position along the path.
    """

    # Clamp parameter to valid bounds
    if t <= 0:
        return path[0]
    if t >= 1:
        return path[-1]

    # Map normalized parameter to discrete path indices
    index = t * (len(path) - 1)
    i = int(np.floor(index))
    alpha = index - i  # Local interpolation factor

    p1 = np.array(path[i])
    p2 = np.array(path[i + 1])

    # Linear interpolation between neighboring points
    return (p1 * (1 - alpha) + p2 * alpha).tolist()
