from coppeliasim_zmqremoteapi_client import RemoteAPIClient
from Warehouse_Creation.generate_waypoints import generate_warehouse_nodes

from Warehouse_Creation.clean_scene import clean 
from Warehouse_Creation.create_floor import create_floor_from_nodes
from Warehouse_Creation.create_area import create_area_zone
from Warehouse_Creation.create_shelves import create_shelves_from_waypoints
from Warehouse_Creation.import_agvs import import_all_agvs
from Warehouse_Creation.save_scene import save_scene

from Warehouse_Creation.export_nodes import export_nodes_to_coppeliasim, save_waypoints_to_csv

from Warehouse_Creation.create_graph import build_graph, edges_to_graph, save_graph_to_csv, save_graph_json
from Warehouse_Creation import visualize_graph

from Task_Managment.pallet_scheduler import PalletScheduler
from Task_Managment.order_simulator import OrderSimulator

import Presentation.Config_GUI as Config_GUI
from Presentation.Menu_GUI import WarehouseMenuGUI

import json
import networkx as nx
import tkinter as tk


# Initialize GUI
root = tk.Tk()
app = Config_GUI.MatrixInputApp(root)
root.mainloop()

# Get values from Config GUI
config_values = app.get_values()

# -------------------------------------------------------------
# MAIN EXECUTION
# -------------------------------------------------------------
if __name__ == "__main__":

    # -------- Warehouse parameters from Config GUI ------------
    n_aisles = config_values['n_aisles']
    coloums_per_shelf = config_values['colums_per_shelf']
    levels_per_shelf = config_values['levels_per_shelf']
    n_agvs = config_values['num_agvs']

    # -------- Advanced warehouse parameters from Config GUI ------------
    aisle_width = config_values['aisle_width']
    shelf_depth = config_values['shelf_depth']
    shelf_height = config_values['shelf_height']
    shelf_width = config_values['shelf_width']

    
    # -------- Additional fixed parameters --------
    base_y = 0.0                    # Base Y position of the warehouse 
    meeting_offset = 1.5            # Offset for meeting areas from aisle center
    shipping_offset = 1.5           # Offset for shipping area from last aisle
    slot_length = shelf_width   
    agvs_speed = 3                  # AGV speed [m/s]
    spawn_pallet_interval = 10      # Time between pallet spawns [s]
    spacing = 2                     # Distance between meeting areas
    spawn_offset = 3.0              # Distance of spawn area from meeting areas


    # --------------------------------------------------------
    # 1) Generate warehouse nodes and create the scene
    # --------------------------------------------------------
    nodes = generate_warehouse_nodes(
        n_aisles, coloums_per_shelf, levels_per_shelf,
        aisle_width, slot_length, shelf_height, shelf_depth, base_y,
        meeting_offset, shipping_offset, n_agvs, spacing, spawn_offset
    )

    # Save waypoints to CSV file 
    save_waypoints_to_csv(nodes, "File_CSV/waypoints.csv")

    # Connect to CoppeliaSim via ZMQ Remote API
    client = RemoteAPIClient()
    sim = client.getObject("sim")
    print("➡ Connected to CoppeliaSim.")

    # Load empty scene and clean old objects
    sim.loadScene("")     
    clean(sim)            

    # Create visual dummies for each waypoint
    export_nodes_to_coppeliasim(sim, nodes)  

    # -------- Scene visualization --------
    create_floor_from_nodes(sim, nodes)  # Generate floor based on warehouse size

    # Create meeting areas
    for node_id, node in nodes.items():
        if node_id.startswith("MEETING_AREA"):
            create_area_zone(sim, node_id, node.pos)

    # Create shipping area
    create_area_zone(sim, "SHIPPING_AREA", nodes["SHIPPING_AREA"].pos)    

    # Create spawn area (green)                 
    create_area_zone(sim, "SPAWN_AREA", nodes["SPAWN_AREA"].pos, 
                     width=1.0, height=1.0, color=[0.3, 0.6, 0.3], transparency=0.2) 
    
    # Create spawn exit area (blue)       
    create_area_zone(sim, "SPAWN_EXIT", nodes["SPAWN_EXIT"].pos, 
                     width=1.0, height=1.0, color=[0.2, 0.5, 0.7], transparency=0.2)    
    
    # Generate shelf geometry    
    create_shelves_from_waypoints(sim, nodes, shelf_width, shelf_depth, shelf_height)    

    # Import AGV models into the scene
    agv_handles = import_all_agvs(                                                        
        sim,
        nodes,
        r"C:\Users\fedef\OneDrive\Desktop\Project_Simulation\Agvs_Model\Omnidirectional Platform.ttm"
    )

    # Save the generated warehouse scene
    save_scene(sim, "Warehouse.ttt")


    # --------------------------------------------------------
    # 2) Generate weighted navigation graph
    # --------------------------------------------------------
    edges = build_graph(nodes)
    graph = edges_to_graph(edges)

    # Save graph structure to files
    save_graph_to_csv(edges, "File_CSV/graph.csv")
    save_graph_json(graph, "File_CSV/graph.json")


    # --------------------------------------------------------
    # 3) Load graph into NetworkX for AGV path planning
    # --------------------------------------------------------
    with open("File_CSV/graph.json") as f:
        data = json.load(f)

    G = nx.DiGraph()
    for u in data:
        for v, w in data[u].items():
            G.add_edge(u, v, weight=w)
    
    # --------------------------------------------------------
    # 4) Create and run order simulator
    # --------------------------------------------------------
    order_simulator = OrderSimulator(
        mean_orders_per_hour=180,     # Average order rate
        std_dev=5,                    # Order rate variability
        simulation_hours=24,          # Total simulation time
        warehouse_nodes=nodes         # Warehouse nodes for shelf selection
    )
    
    # Generate orders and compute statistics
    order_simulator.generate_orders()
    order_simulator.get_statistics()
    

    # --------------------------------------------------------
    # 5) Launch main warehouse management GUI
    # --------------------------------------------------------
    menu_root = tk.Tk()
    menu_app = WarehouseMenuGUI(
        menu_root,
        sim,
        nodes,
        agv_handles,
        G,
        visualize_graph,
        PalletScheduler,
        order_simulator
    )
    menu_root.mainloop()


