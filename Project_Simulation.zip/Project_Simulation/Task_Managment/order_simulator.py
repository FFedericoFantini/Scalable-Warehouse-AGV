import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import json


class OrderSimulator:
    def __init__(self, mean_orders_per_hour=50, std_dev=15, simulation_hours=24, warehouse_nodes=None):
        """
        Initialize the order simulator.

        Args:
            mean_orders_per_hour: Average number of orders per hour
            std_dev: Standard deviation of the hourly order count
            simulation_hours: Total duration of the simulation (in hours)
            warehouse_nodes: Dictionary of warehouse nodes used to select shelf locations
        """
        self.mean_orders_per_hour = mean_orders_per_hour
        self.std_dev = std_dev
        self.simulation_hours = simulation_hours
        self.warehouse_nodes = warehouse_nodes
        self.orders = []

        # Extract all shelf locations from the provided warehouse nodes
        self.shelf_locations = []
        if warehouse_nodes:
            self.shelf_locations = [node_id for node_id in warehouse_nodes.keys()
                                   if "_X" in node_id and "_L" in node_id]

    def generate_orders(self):
        """Generate orders using a Gaussian distribution for each simulated hour."""
        np.random.seed(42)  # Ensure reproducible results

        start_time = datetime.now()

        for hour in range(self.simulation_hours):
            # Number of orders generated for the current hour (Gaussian)
            num_orders = int(max(0, np.random.normal(self.mean_orders_per_hour, self.std_dev)))

            # Generate orders uniformly distributed within the hour
            for _ in range(num_orders):
                # Random minute offset within the hour
                minutes = np.random.uniform(0, 60)
                order_time = start_time + timedelta(hours=hour, minutes=minutes)

                # Select a random shelf location if available
                shelf_location = None
                if self.shelf_locations:
                    shelf_location = np.random.choice(self.shelf_locations)

                order = {
                    'order_id': len(self.orders) + 1,
                    'timestamp': order_time.isoformat(),
                    'hour': hour,
                    'shelf_location': shelf_location,
                    'status': 'pending'  # pending, assigned, in_progress, completed
                }
                self.orders.append(order)

        return self.orders

    def save_to_file(self, filename='orders.json'):
        """Save the generated orders to a JSON file."""
        with open(filename, 'w') as f:
            json.dump(self.orders, f, indent=2)

    def plot_distribution(self):
        """Plot and save the distribution of generated orders across simulation hours."""
        hours = [order['hour'] for order in self.orders]

        plt.figure(figsize=(12, 6))
        plt.hist(hours, bins=self.simulation_hours, edgecolor='black', alpha=0.7)
        plt.xlabel('Hour of day')
        plt.ylabel('Number of orders')
        plt.title('Order Distribution (Gaussian)')
        plt.grid(True, alpha=0.3)
        plt.savefig('order_distribution.png')
        plt.show()

    def get_statistics(self):
        """Print summary statistics for the generated orders."""
        pass

    def get_pending_orders(self):
        """Return a list of all orders currently in 'pending' status."""
        return [order for order in self.orders if order['status'] == 'pending']

    def get_orders_for_hour(self, hour):
        """Return pending orders for a given hour of the simulation."""
        return [order for order in self.orders if order['hour'] == hour and order['status'] == 'pending']

    def mark_order_assigned(self, order_id):
        """Set the status of the specified order to 'assigned'."""
        for order in self.orders:
            if order['order_id'] == order_id:
                order['status'] = 'assigned'
                return True
        return False

    def mark_order_in_progress(self, order_id):
        """Set the status of the specified order to 'in_progress'."""
        for order in self.orders:
            if order['order_id'] == order_id:
                order['status'] = 'in_progress'
                return True
        return False

    def mark_order_completed(self, order_id):
        """Set the status of the specified order to 'completed'."""
        for order in self.orders:
            if order['order_id'] == order_id:
                order['status'] = 'completed'
                return True
        return False

    def get_order_by_id(self, order_id):
        """Return a single order dictionary by its order_id (or None if not found)."""
        for order in self.orders:
            if order['order_id'] == order_id:
                return order
        return None

    def get_order_statistics(self):
        """Compute and return a summary dictionary of order counts by status."""
        stats = {
            'total': len(self.orders),
            'pending': sum(1 for o in self.orders if o['status'] == 'pending'),
            'assigned': sum(1 for o in self.orders if o['status'] == 'assigned'),
            'in_progress': sum(1 for o in self.orders if o['status'] == 'in_progress'),
            'completed': sum(1 for o in self.orders if o['status'] == 'completed')
        }
        return stats

    def print_order_statistics(self):
        """Print a human-readable summary of the current order status statistics."""
        pass


if __name__ == "__main__":
    # Instantiate the simulator with default parameters
    simulator = OrderSimulator(
        mean_orders_per_hour=50,  # Average orders per hour
        std_dev=15,                # Standard deviation
        simulation_hours=24        # Total simulation duration (24 hours)
    )

    # Generate simulated orders
    simulator.generate_orders()

    # Save generated orders to disk
    simulator.save_to_file('orders.json')

    # Print summary statistics
    simulator.get_statistics()

    # Plot the hourly distribution of generated orders
    simulator.plot_distribution()
