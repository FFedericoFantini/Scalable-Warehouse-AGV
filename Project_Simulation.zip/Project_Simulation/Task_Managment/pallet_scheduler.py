import time
import random
import threading
import math
import networkx as nx

from Path_Generation.path_generator import generate_path_from_waypoints
from Path_Generation.move_along_path import move_agv_along_path

random.seed(2)

# -----------------------------------------------------------
# ANIMATION UTILITIES
# -----------------------------------------------------------

def animate_pallet_lift(sim, pallet, start_z, end_z, duration=0.5, lock=None):
    """
    Smooth animation for pallet lifting or lowering.
    - start_z: initial Z world coordinate
    - end_z: target Z world coordinate
    - duration: animation time in seconds
    """
    t0 = time.time()
    while True:
        elapsed = time.time() - t0
        alpha = min(elapsed / duration, 1.0)

        current_z = start_z * (1 - alpha) + end_z * alpha

        if lock:
            with lock:
                pos = sim.getObjectPosition(pallet, -1)
                sim.setObjectPosition(pallet, -1, [pos[0], pos[1], current_z])
        else:
            pos = sim.getObjectPosition(pallet, -1)
            sim.setObjectPosition(pallet, -1, [pos[0], pos[1], current_z])

        if alpha >= 1.0:
            break

        time.sleep(0.02)  # 50 Hz


def animate_pallet_slide(sim, pallet, start_x, start_y, end_x, end_y, current_z, duration=0.5, lock=None):
    """
    Smooth animation for pallet horizontal sliding.
    """
    t0 = time.time()
    while True:
        elapsed = time.time() - t0
        alpha = min(elapsed / duration, 1.0)

        current_x = start_x * (1 - alpha) + end_x * alpha
        current_y = start_y * (1 - alpha) + end_y * alpha

        if lock:
            with lock:
                sim.setObjectPosition(pallet, -1, [current_x, current_y, current_z])
        else:
            sim.setObjectPosition(pallet, -1, [current_x, current_y, current_z])

        if alpha >= 1.0:
            break

        time.sleep(0.02)  # 50 Hz


# -----------------------------------------------------------
# GRAPH SUPPORT FUNCTIONS
# -----------------------------------------------------------

def get_closest_graph_node(nodes, pos):
    x, y = pos
    return min(
        nodes.keys(),
        key=lambda nid: (nodes[nid].pos[0] - x) ** 2 + (nodes[nid].pos[1] - y) ** 2
    )


def graph_nodes_to_positions(graph_path, nodes):
    return [nodes[nid].pos for nid in graph_path]


def compute_motion_path(G, nodes, start_pos, target_node_id, reserved_edges=None):

    start_node_id = get_closest_graph_node(nodes, start_pos)

    # Copy graph removing reserved edges
    if reserved_edges:
        G_tmp = G.copy()
        for (u, v) in reserved_edges:
            if G_tmp.has_edge(u, v):
                G_tmp.remove_edge(u, v)
    else:
        G_tmp = G

    try:
        graph_path = nx.shortest_path(
            G_tmp, start_node_id, target_node_id, weight="weight"
        )
    except nx.NetworkXNoPath:
        # fallback: try complete graph
        graph_path = nx.shortest_path(
            G, start_node_id, target_node_id, weight="weight"
        )

    # already at target
    if len(graph_path) == 1:
        p = nodes[graph_path[0]].pos
        return [[p[0], p[1]], [p[0], p[1]]], set()

    positions = graph_nodes_to_positions(graph_path, nodes)
    motion_path = generate_path_from_waypoints(positions, step=0.05)

    used_edges = set(zip(graph_path[:-1], graph_path[1:]))
    return motion_path, used_edges



# -----------------------------------------------------------
# PALLET SCHEDULER WITH EDGE RESERVATION
# -----------------------------------------------------------

class PalletScheduler:

    def __init__(self, sim, nodes, agvs, speed, G, spawn_interval, order_simulator=None):
        self.sim = sim
        self.nodes = nodes
        self.agvs = agvs
        self.G = G
        self.speed = speed
        self.spawn_interval = spawn_interval
        self.order_simulator = order_simulator

        self.api_lock = threading.Lock()
        self.running = False  # Control flag for stopping the simulation
        self.current_hour = 0
        self.start_time = None

        self.meeting_areas = sorted(
            [n for nid, n in nodes.items() if nid.startswith("MEETING_AREA")],
            key=lambda x: x.id
        )

        self.shelf_slots = [
            n for nid, n in nodes.items()
            if ("_S1_X" in nid or "_S2_X" in nid) and "_L" in nid
        ]  

        

        self.pending_pallets = []  # Pallets waiting to be stored
        self.stored_pallets = {}   # {shelf_node_id: pallet_handle} - pallets in storage
        self.available_slots = list(self.shelf_slots)  # Available shelf slots

        self.agv_busy = {agv: False for agv in agvs}

        self.agv_home = {}
        for i, agv in enumerate(agvs):
            self.agv_home[agv] = self.meeting_areas[i]

        self.agv_edges = {agv: set() for agv in agvs}
        
        # Statistics tracking
        self.total_pallets_stored = 0
        self.total_orders_completed = 0

    
    # -----------------------------------------------------------
    # GET AGV NAME
    # -----------------------------------------------------------
    def get_agv_name(self, agv_handle):
        with self.api_lock:
            try:
                return self.sim.getObjectAlias(agv_handle)
            except:
                return str(agv_handle)

    # -----------------------------------------------------------
    # SPAWN PALLET AT SPAWN AREA
    # -----------------------------------------------------------
    def spawn_pallet(self):
        """Spawn a pallet at the spawn area."""
        spawn_area = self.nodes["SPAWN_AREA"]
        x, y, z = spawn_area.pos

        with self.api_lock:
            # Create pallet as a real shape
            pallet = self.sim.createPureShape(
                0,                      # cuboid
                0,                      # options
                [0.50, 0.50, 0.15],     # length, width, height
                1                       # respondable
            )

            self.sim.setObjectAlias(pallet, f"Pallet_{time.time():.0f}")
            self.sim.setObjectPosition(pallet, -1, [x, y, z + 0.3])

            # Dark brown color
            self.sim.setShapeColor(
                pallet,
                None,
                self.sim.colorcomponent_ambient_diffuse,
                [0.35, 0.20, 0.05]  # dark wood brown
            )

        self.pending_pallets.append((pallet, spawn_area))
        return pallet


    # -----------------------------------------------------------
    # ASSIGN STORAGE MISSION (MEETING AREA → SHELF)
    # -----------------------------------------------------------
    def assign_storage_mission(self):
        """Assign a mission to store a pallet from meeting area to shelf."""
        if not self.pending_pallets or not self.available_slots:
            return

        free_agvs = [a for a in self.agvs if not self.agv_busy[a]]
        if not free_agvs:
            return

        pallet, meeting_node = self.pending_pallets.pop(0)
        target_slot = random.choice(self.available_slots)
        self.available_slots.remove(target_slot)

        best_agv = None
        best_dist = float("inf")

        # Choose AGV nearest to pallet at meeting area
        for agv in free_agvs:
            with self.api_lock:
                agv_pos = self.sim.getObjectPosition(agv, -1)

            dx = agv_pos[0] - meeting_node.pos[0]
            dy = agv_pos[1] - meeting_node.pos[1]
            dist = math.hypot(dx, dy)

            if dist < best_dist:
                best_dist = dist
                best_agv = agv

        self.agv_busy[best_agv] = True

        threading.Thread(
            target=self._run_storage_mission,
            args=(best_agv, pallet, meeting_node, target_slot),
            daemon=True
        ).start()

    # -----------------------------------------------------------
    # ASSIGN RETRIEVAL MISSION (SHELF → SHIPPING)
    # -----------------------------------------------------------
    def assign_retrieval_mission(self, order):
        """Assign a mission to retrieve a pallet from shelf and deliver to shipping."""
        shelf_location = order['shelf_location']
        
        # Check if there's a pallet at this shelf location
        if shelf_location not in self.stored_pallets:
            return False

        free_agvs = [a for a in self.agvs if not self.agv_busy[a]]
        if not free_agvs:
            return False

        pallet = self.stored_pallets[shelf_location]
        shelf_node = self.nodes[shelf_location]
        
        best_agv = None
        best_dist = float("inf")

        # Choose AGV nearest to shelf location
        for agv in free_agvs:
            with self.api_lock:
                agv_pos = self.sim.getObjectPosition(agv, -1)

            dx = agv_pos[0] - shelf_node.pos[0]
            dy = agv_pos[1] - shelf_node.pos[1]
            dist = math.hypot(dx, dy)

            if dist < best_dist:
                best_dist = dist
                best_agv = agv

        self.agv_busy[best_agv] = True

        # Mark order as in progress
        if self.order_simulator:
            self.order_simulator.mark_order_in_progress(order['order_id'])

        threading.Thread(
            target=self._run_retrieval_mission,
            args=(best_agv, pallet, shelf_node, order['order_id']),
            daemon=True
        ).start()
        
        return True

    # -----------------------------------------------------------
    # ASSIGN MISSION (LEGACY - DIRECT DELIVERY)
    # -----------------------------------------------------------
    def assign_mission(self, order_id=None):
        """Assign a mission to pick up pallet and deliver to shipping area."""
        if not self.pending_pallets:
            return

        free_agvs = [a for a in self.agvs if not self.agv_busy[a]]
        if not free_agvs:
            return

        pallet, meeting_node = self.pending_pallets.pop(0)

        best_agv = None
        best_dist = float("inf")

        # Choose AGV nearest to pallet at meeting area
        for agv in free_agvs:
            with self.api_lock:
                agv_pos = self.sim.getObjectPosition(agv, -1)

            dx = agv_pos[0] - meeting_node.pos[0]
            dy = agv_pos[1] - meeting_node.pos[1]
            dist = math.hypot(dx, dy)

            if dist < best_dist:
                best_dist = dist
                best_agv = agv

        self.agv_busy[best_agv] = True

        # Mark order as in progress
        if order_id and self.order_simulator:
            self.order_simulator.mark_order_in_progress(order_id)

        threading.Thread(
            target=self._run_mission,
            args=(best_agv, pallet, meeting_node, order_id),
            daemon=True
        ).start()

    # -----------------------------------------------------------
    # RUN STORAGE MISSION (MEETING AREA → SHELF)
    # -----------------------------------------------------------
    def _run_storage_mission(self, agv, pallet, meeting_node, target_slot):
        """Store a pallet from meeting area to shelf slot."""

        # 1️⃣ GO TO MEETING AREA TO PICKUP
        with self.api_lock:
            agv_pos = self.sim.getObjectPosition(agv, -1)
            reserved_edges = set()
            for other in self.agvs:
                if other != agv and self.agv_busy.get(other, False):
                    for e in self.agv_edges.get(other, set()):
                                reserved_edges.add(e)
                                reserved_edges.add((e[1], e[0])) # also block opposite edge
            reserved_edges -= self.agv_edges[agv]

        start = (agv_pos[0], agv_pos[1])
        path_to_meeting, edges_to_meeting = compute_motion_path(
            self.G, self.nodes, start, meeting_node.id, reserved_edges
        )

        with self.api_lock:
            self.agv_edges[agv] |= edges_to_meeting

        move_agv_along_path(self.sim, agv, path_to_meeting, self.speed, lock=self.api_lock, all_agvs=self.agvs)

        # Attach pallet to AGV
        with self.api_lock:
            self.sim.setObjectParent(pallet, agv, True)

        # 2️⃣ GO TO SHELF CORRIDOR (not the slot itself)
        # Extract aisle, side, and column from slot ID
        # New format: "A2_S1_X4_L1" or "A2_S2_X4_L1"
        slot_id = target_slot.id
        parts = slot_id.split("_")
        aisle = parts[0]          # "A2"
        side = parts[1]           # "S1" or "S2"
        col = parts[2]            # "X4"
        
        # Use the corresponding path: P1 for S1, P2 for S2
        path_num = side[1]  # Extract "1" or "2" from "S1" or "S2"
        corridor_id = f"{aisle}_P{path_num}_{col}"  # "A2_P1_X4" or "A2_P2_X4"
        corridor_node = self.nodes[corridor_id]

        with self.api_lock:
            agv_pos = self.sim.getObjectPosition(agv, -1)
            reserved_edges = set()
            for other in self.agvs:
                if other != agv and self.agv_busy.get(other, False):
                    for e in self.agv_edges.get(other, set()):
                                reserved_edges.add(e)
                                reserved_edges.add((e[1], e[0])) # also block opposite edge
            reserved_edges -= self.agv_edges.get(agv, set())

        start = (agv_pos[0], agv_pos[1])
        path_to_corridor, edges_to_corridor = compute_motion_path(
            self.G, self.nodes, start, corridor_id, reserved_edges
        )

        with self.api_lock:
            self.agv_edges[agv] |= edges_to_corridor

        move_agv_along_path(self.sim, agv, path_to_corridor, self.speed, lock=self.api_lock, all_agvs=self.agvs)

        # 3️⃣ Place pallet at shelf with animation
        # Detach pallet from AGV
        with self.api_lock:
            self.sim.setObjectParent(pallet, -1, True)
            px, py, pz = self.sim.getObjectPosition(pallet, -1)
        
        # Get target shelf position
        slot_x, slot_y, slot_z = target_slot.pos
        target_z = slot_z + 0.075  # Half pallet height above shelf level
        
        # Calculate clearance height (above highest shelf if multi-level)
        lift_clearance = 0.1
        lift_z = max(pz, target_z) + lift_clearance
        
        # Animation sequence:
        # a) Lift pallet above shelf height
        animate_pallet_lift(self.sim, pallet, pz, lift_z, 0.6, lock=self.api_lock)
        
        # b) Slide pallet horizontally into shelf
        animate_pallet_slide(self.sim, pallet, px, py, slot_x, slot_y, lift_z, 0.8, lock=self.api_lock)
        
        # c) Lower pallet to final shelf position
        animate_pallet_lift(self.sim, pallet, lift_z, target_z, 0.6, lock=self.api_lock)
        
        # Store pallet location
        self.stored_pallets[target_slot.id] = pallet
        self.total_pallets_stored += 1


        # 4️⃣ RETURN HOME
        home = self.agv_home[agv]
        
        with self.api_lock:
            agv_pos = self.sim.getObjectPosition(agv, -1)
            reserved_edges = set()
            for other in self.agvs:
                if other != agv and self.agv_busy.get(other, False):
                    for e in self.agv_edges.get(other, set()):
                                reserved_edges.add(e)
                                reserved_edges.add((e[1], e[0])) # also block opposite edge
            reserved_edges -= self.agv_edges[agv]

        start = (agv_pos[0], agv_pos[1])
        path_return, edges_return = compute_motion_path(
            self.G, self.nodes, start, home.id, reserved_edges
        )

        with self.api_lock:
            self.agv_edges[agv] |= edges_return

        move_agv_along_path(self.sim, agv, path_return, self.speed, lock=self.api_lock, all_agvs=self.agvs)

        # Free AGV
        with self.api_lock:
            self.agv_edges[agv].clear()
            self.agv_busy[agv] = False

    # -----------------------------------------------------------
    # RUN RETRIEVAL MISSION (SHELF → SHIPPING)
    # -----------------------------------------------------------
    def _run_retrieval_mission(self, agv, pallet, shelf_node, order_id):
        """Retrieve a pallet from shelf and deliver to shipping area."""

        # 1️⃣ GO TO SHELF CORRIDOR (not the slot itself)
        # Extract aisle, side, and column from slot ID
        # New format: "A2_S1_X4_L1" or "A2_S2_X4_L1"
        slot_id = shelf_node.id
        parts = slot_id.split("_")
        aisle = parts[0]          # "A2"
        side = parts[1]           # "S1" or "S2"
        col = parts[2]            # "X4"
        
        # Use the corresponding path: P1 for S1, P2 for S2
        path_num = side[1]  # Extract "1" or "2" from "S1" or "S2"
        corridor_id = f"{aisle}_P{path_num}_{col}"  # "A2_P1_X4" or "A2_P2_X4"
        corridor_node = self.nodes[corridor_id]

        with self.api_lock:
            agv_pos = self.sim.getObjectPosition(agv, -1)
            reserved_edges = set()
            for other in self.agvs:
                if other != agv and self.agv_busy.get(other, False):
                    for e in self.agv_edges.get(other, set()):
                                reserved_edges.add(e)
                                reserved_edges.add((e[1], e[0])) # also block opposite edge
            reserved_edges -= self.agv_edges.get(agv, set())

        start = (agv_pos[0], agv_pos[1])
        path_to_corridor, edges_to_corridor = compute_motion_path(
            self.G, self.nodes, start, corridor_id, reserved_edges
        )

        with self.api_lock:
            self.agv_edges[agv] |= edges_to_corridor

        move_agv_along_path(self.sim, agv, path_to_corridor, self.speed, lock=self.api_lock, all_agvs=self.agvs)

        # 2️⃣ Pick pallet from shelf with animation
        with self.api_lock:
            # Get current pallet position (at shelf)
            px, py, pz = self.sim.getObjectPosition(pallet, -1)
            # Get AGV position
            agv_pos = self.sim.getObjectPosition(agv, -1)
            agv_x, agv_y, agv_z = agv_pos
        
        # Animation sequence (reverse of storage):
        # a) Lift pallet from shelf
        lift_clearance = 0.1
        lift_z = pz + lift_clearance
        animate_pallet_lift(self.sim, pallet, pz, lift_z, 0.6, lock=self.api_lock)
        
        # b) Slide pallet horizontally out to corridor (AGV position)
        animate_pallet_slide(self.sim, pallet, px, py, agv_x, agv_y, lift_z, 0.8, lock=self.api_lock)
        
        # c) Lower pallet to AGV height
        animate_pallet_lift(self.sim, pallet, lift_z, agv_z + 0.3, 0.6, lock=self.api_lock)
        
        # d) Attach to AGV
        with self.api_lock:
            self.sim.setObjectParent(pallet, agv, True)

        # Remove from stored pallets
        del self.stored_pallets[shelf_node.id]
        self.available_slots.append(shelf_node)

        # 3️⃣ DELIVER TO SHIPPING AREA
        with self.api_lock:
            agv_pos = self.sim.getObjectPosition(agv, -1)
            reserved_edges = set()
            for other in self.agvs:
                if other != agv and self.agv_busy.get(other, False):
                    for e in self.agv_edges.get(other, set()):
                                reserved_edges.add(e)
                                reserved_edges.add((e[1], e[0])) # also block opposite edge
            reserved_edges -= self.agv_edges[agv]

        start = (agv_pos[0], agv_pos[1])
        path_to_shipping, edges_to_shipping = compute_motion_path(
            self.G, self.nodes, start, "SHIPPING_AREA", reserved_edges
        )

        with self.api_lock:
            self.agv_edges[agv] |= edges_to_shipping

        move_agv_along_path(self.sim, agv, path_to_shipping, self.speed, lock=self.api_lock, all_agvs=self.agvs)

        # Detach pallet at shipping area
        with self.api_lock:
            self.sim.setObjectParent(pallet, -1, True)
        
        # Mark order as completed
        if self.order_simulator:
            self.order_simulator.mark_order_completed(order_id)
            self.total_orders_completed += 1

        # 4️⃣ RETURN HOME
        home = self.agv_home[agv]
        with self.api_lock:
            agv_pos = self.sim.getObjectPosition(agv, -1)
            reserved_edges = set()
            for other in self.agvs:
                if other != agv and self.agv_busy.get(other, False):
                    for e in self.agv_edges.get(other, set()):
                                reserved_edges.add(e)
                                reserved_edges.add((e[1], e[0])) # also block opposite edge
            reserved_edges -= self.agv_edges[agv]

        start = (agv_pos[0], agv_pos[1])
        path_return, edges_return = compute_motion_path(
            self.G, self.nodes, start, home.id, reserved_edges
        )

        with self.api_lock:
            self.agv_edges[agv] |= edges_return

        move_agv_along_path(self.sim, agv, path_return, self.speed, lock=self.api_lock, all_agvs=self.agvs)

        # Free AGV
        with self.api_lock:
            self.agv_edges[agv].clear()
            self.agv_busy[agv] = False

    # -----------------------------------------------------------
    # GET SIMULATION STATISTICS
    # -----------------------------------------------------------
    def get_statistics(self):
        """Return current simulation statistics."""
        stats = {
            'pallets_stored': len(self.stored_pallets),
            'total_stored': self.total_pallets_stored,
            'total_slots': len(self.shelf_slots),
            'available_slots': len(self.available_slots),
            'orders_completed': self.total_orders_completed,
            'pending_pallets': len(self.pending_pallets),
            'busy_agvs': sum(1 for busy in self.agv_busy.values() if busy),
            'free_agvs': sum(1 for busy in self.agv_busy.values() if not busy)
        }
        return stats
    


    # -----------------------------------------------------------
    # MAIN LOOP (ORDER-TRIGGERED DELIVERY)
    # -----------------------------------------------------------
    def run(self):
        self.running = True
        self.start_time = time.time()
        last_spawn = time.time()
        last_check = time.time()
        last_stats = time.time()
        processed_orders = set()
        pending_order_queue = []  # Queue for orders waiting for pallets to be stored

        while self.running:
            # Spawn pallets at regular intervals at meeting areas
            if time.time() - last_spawn >= self.spawn_interval:
                self.spawn_pallet()
                last_spawn = time.time()
            
            # Assign storage missions for pending pallets
            self.assign_storage_mission()
            
            # Print statistics every 30 seconds
            if time.time() - last_stats >= 30:
                if self.order_simulator:
                    self.order_simulator.print_order_statistics()
                last_stats = time.time()
            
            # Check for new orders and assign retrieval missions
            if self.order_simulator and time.time() - last_check >= 1:
                # Calculate current simulation hour
                elapsed = time.time() - self.start_time
                self.current_hour = int(elapsed / 10)  # 10 seconds = 1 simulated hour
                
                # Get pending orders for current hour
                pending_orders = self.order_simulator.get_orders_for_hour(self.current_hour)
                
                # Process new orders
                for order in pending_orders:
                    if order['order_id'] not in processed_orders:
                        shelf_location = order['shelf_location']
                        
                        # Check if pallet is already stored at this location
                        if shelf_location in self.stored_pallets:
                            self.order_simulator.mark_order_assigned(order['order_id'])
                            processed_orders.add(order['order_id'])
                            success = self.assign_retrieval_mission(order)
                            if not success:
                                # No AGVs available, try again later
                                pending_order_queue.append(order)
                        else:
                            # Pallet not yet stored, add to waiting queue
                            if order not in pending_order_queue:
                                pending_order_queue.append(order)
                                processed_orders.add(order['order_id'])
                
                # Try to process orders from the waiting queue
                orders_to_remove = []
                for order in pending_order_queue:
                    shelf_location = order['shelf_location']
                    if shelf_location in self.stored_pallets:
                        self.order_simulator.mark_order_assigned(order['order_id'])
                        success = self.assign_retrieval_mission(order)
                        if success:
                            orders_to_remove.append(order)
                
                # Remove successfully processed orders from queue
                for order in orders_to_remove:
                    pending_order_queue.remove(order)
                
                last_check = time.time()

            time.sleep(0.2)
    
    # -----------------------------------------------------------
    # STOP SIMULATION
    # -----------------------------------------------------------
    def stop(self):
        """Stop the simulation loop."""
        self.running = False
        print("\n⏸️  Stopping simulation...")
