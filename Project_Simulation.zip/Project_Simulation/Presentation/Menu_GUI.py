import tkinter as tk
from tkinter import messagebox
import threading

class WarehouseMenuGUI:
    def __init__(self, root, sim, nodes, agv_handles, G, visualize_graph, PalletScheduler, order_simulator=None):
        self.root = root
        self.sim = sim
        self.nodes = nodes
        self.agv_handles = agv_handles
        self.G = G
        self.visualize_graph = visualize_graph
        self.PalletScheduler = PalletScheduler
        self.order_simulator = order_simulator
        
        # Simulation control attributes
        self.scheduler = None
        self.simulation_thread = None
        self.is_simulation_running = False
        
        # Main window configuration
        self.root.title("Warehouse Simulation Menu")
        self.root.geometry("550x600")
        self.root.configure(bg='#f0f0f0')
        self.root.resizable(False, False)
        
        self.setup_ui()
    
    def setup_ui(self):
        # ---------------------------------------------------
        # Title section (header)
        # ---------------------------------------------------
        title_frame = tk.Frame(self.root, bg='#2c3e50', pady=20)
        title_frame.pack(fill='x')
        tk.Label(
            title_frame, 
            text="WAREHOUSE SIMULATION", 
            font=("Segoe UI", 18, "bold"),
            bg='#2c3e50',
            fg='white'
        ).pack()
        
        # ---------------------------------------------------
        # Simulation status label
        # ---------------------------------------------------
        status_container = tk.Frame(self.root, bg='#f0f0f0')
        status_container.pack(pady=15)
        self.status_label = tk.Label(
            status_container,
            text="Status: Ready",
            font=("Segoe UI", 11),
            fg="gray",
            bg='#f0f0f0'
        )
        self.status_label.pack()
        
        # ---------------------------------------------------
        # Control panel container
        # ---------------------------------------------------
        button_container = tk.LabelFrame(
            self.root,
            text="Control Panel",
            font=("Segoe UI", 12, "bold"),
            bg='#f0f0f0',
            padx=30,
            pady=20,
            relief='groove',
            borderwidth=2
        )
        button_container.pack(pady=20, padx=40, fill='both', expand=True)
        
        button_frame = tk.Frame(button_container, bg='#f0f0f0')
        button_frame.pack()
        
        # ---------------------------------------------------
        # Button: Visualize warehouse graph
        # ---------------------------------------------------
        self.btn_visualize = tk.Button(
            button_frame,
            text="📊 Visualize Graph of Warehouse",
            command=self.visualize_warehouse,
            width=35,
            height=2,
            bg="#4CAF50",
            fg="white",
            font=("Segoe UI", 11, "bold"),
            relief='flat',
            cursor='hand2',
            padx=20,
            pady=12
        )
        self.btn_visualize.pack(pady=12)
        self.btn_visualize.bind('<Enter>', lambda e: self.btn_visualize.config(bg='#388E3C'))
        self.btn_visualize.bind('<Leave>', lambda e: self.btn_visualize.config(bg='#4CAF50'))
        
        # ---------------------------------------------------
        # Button: Start simulation
        # ---------------------------------------------------
        self.btn_simulate = tk.Button(
            button_frame,
            text="▶ Start Simulation",
            command=self.start_simulation,
            width=35,
            height=2,
            bg="#3498db",
            fg="white",
            font=("Segoe UI", 11, "bold"),
            relief='flat',
            cursor='hand2',
            padx=20,
            pady=12
        )
        self.btn_simulate.pack(pady=12)
        self.btn_simulate.bind('<Enter>', lambda e: self.btn_simulate.config(bg='#2980b9'))
        self.btn_simulate.bind('<Leave>', lambda e: self.btn_simulate.config(bg='#3498db'))
        
        # ---------------------------------------------------
        # Button: Stop simulation
        # ---------------------------------------------------
        self.btn_stop = tk.Button(
            button_frame,
            text="⏹ Stop Simulation",
            command=self.stop_simulation,
            width=35,
            height=2,
            bg="#f44336",
            fg="white",
            font=("Segoe UI", 11, "bold"),
            relief='flat',
            cursor='hand2',
            padx=20,
            pady=12,
            state=tk.DISABLED,
            disabledforeground="white"
        )
        self.btn_stop.pack(pady=12)
        self.btn_stop.bind('<Enter>', lambda e: self.btn_stop.config(bg='#d32f2f', fg='white') if self.btn_stop['state'] == 'normal' else None)
        self.btn_stop.bind('<Leave>', lambda e: self.btn_stop.config(bg='#f44336', fg='white') if self.btn_stop['state'] == 'normal' else None)
        
        # ---------------------------------------------------
        # Button: Show simulation statistics
        # ---------------------------------------------------
        self.btn_stats = tk.Button(
            button_frame,
            text="📊 Show Statistics",
            command=self.show_statistics,
            width=35,
            height=2,
            bg="#FF9800",
            fg="white",
            font=("Segoe UI", 11, "bold"),
            relief='flat',
            cursor='hand2',
            padx=20,
            pady=12,
            state=tk.DISABLED,
            disabledforeground="white"
        )
        self.btn_stats.pack(pady=12)
        self.btn_stats.bind('<Enter>', lambda e: self.btn_stats.config(bg='#F57C00') if self.btn_stats['state'] == 'normal' else None)
        self.btn_stats.bind('<Leave>', lambda e: self.btn_stats.config(bg='#FF9800') if self.btn_stats['state'] == 'normal' else None)
        
        # ---------------------------------------------------
        # Button: Exit application
        # ---------------------------------------------------
        self.btn_exit = tk.Button(
            button_frame,
            text="✕ Exit",
            command=self.exit_application,
            width=35,
            height=2,
            bg="#9e9e9e",
            fg="white",
            font=("Segoe UI", 11, "bold"),
            relief='flat',
            cursor='hand2',
            padx=20,
            pady=12
        )
        self.btn_exit.pack(pady=12)
        self.btn_exit.bind('<Enter>', lambda e: self.btn_exit.config(bg='#757575'))
        self.btn_exit.bind('<Leave>', lambda e: self.btn_exit.config(bg='#9e9e9e'))
    
    def visualize_warehouse(self):
        """Visualize the warehouse navigation graph."""
        try:
            self.visualize_graph.visualize()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to visualize graph:\n{str(e)}")
    
    def start_simulation(self):
        """Start the warehouse simulation in a separate thread."""
        if self.is_simulation_running:
            messagebox.showwarning("Warning", "Simulation is already running!")
            return
        
        try:
            self.is_simulation_running = True
            self.update_status("Running", "green")
            
            # Update button states
            self.btn_simulate.config(state=tk.DISABLED)
            self.btn_stop.config(state=tk.NORMAL)
            self.btn_stats.config(state=tk.NORMAL)
            
            # Simulation parameters
            agvs_speed = 2
            spawn_pallet_interval = 5
            
            # Initialize pallet scheduler
            self.scheduler = self.PalletScheduler(
                sim=self.sim, 
                nodes=self.nodes, 
                agvs=self.agv_handles, 
                speed=agvs_speed, 
                G=self.G, 
                spawn_interval=spawn_pallet_interval,
                order_simulator=self.order_simulator
            )
            
            # Run simulation in background thread
            self.simulation_thread = threading.Thread(
                target=self._run_simulation,
                daemon=True
            )
            self.simulation_thread.start()
            
        except Exception as e:
            self.is_simulation_running = False
            self.update_status("Error", "red")
            self.btn_simulate.config(state=tk.NORMAL)
            self.btn_stop.config(state=tk.DISABLED)
            messagebox.showerror("Error", f"Failed to start simulation:\n{str(e)}")
    
    def _run_simulation(self):
        """Internal method running the scheduler loop."""
        try:
            self.scheduler.run()
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Simulation Error", str(e)))
        finally:
            self.root.after(0, self._simulation_ended)
    
    def _simulation_ended(self):
        """Handle simulation termination."""
        self.is_simulation_running = False
        self.update_status("Stopped", "orange")
        self.btn_simulate.config(state=tk.NORMAL)
        self.btn_stats.config(state=tk.DISABLED)
    
    def show_statistics(self):
        """Display current simulation statistics in a popup window."""
        if not self.scheduler:
            messagebox.showinfo("Info", "Simulation not running")
            return
        
        try:
            stats = self.scheduler.get_statistics()
            
            # Create statistics window
            stats_window = tk.Toplevel(self.root)
            stats_window.title("Simulation Statistics")
            stats_window.geometry("450x350")
            stats_window.configure(bg='#f0f0f0')
            
            # Header
            title_frame = tk.Frame(stats_window, bg='#2c3e50', pady=15)
            title_frame.pack(fill='x')
            tk.Label(
                title_frame,
                text="📊 SIMULATION STATISTICS",
                font=("Segoe UI", 16, "bold"),
                bg='#2c3e50',
                fg='white'
            ).pack()
            
            # Statistics content
            warehouse_frame = tk.LabelFrame(
                stats_window,
                text="Warehouse Status",
                font=("Segoe UI", 11, "bold"),
                bg='#f0f0f0',
                padx=20,
                pady=15
            )
            warehouse_frame.pack(pady=15, padx=20, fill='both')
            
            warehouse_stats_text = f"""
Pallets in storage:        {stats['pallets_stored']} / {stats['total_slots']}
Total pallets stored:      {stats['total_stored']}
Available slots:           {stats['available_slots']}
Pending pallets:           {stats['pending_pallets']}
Busy AGVs:                 {stats['busy_agvs']} / {stats['busy_agvs'] + stats['free_agvs']}
Free AGVs:                 {stats['free_agvs']} / {stats['busy_agvs'] + stats['free_agvs']}
            """
            tk.Label(
                warehouse_frame,
                text=warehouse_stats_text,
                font=("Consolas", 10),
                bg='#f0f0f0',
                justify='left'
            ).pack()
            
            # Close button
            tk.Button(
                stats_window,
                text="Close",
                command=stats_window.destroy,
                width=20,
                height=2,
                bg="#9e9e9e",
                fg="white",
                font=("Segoe UI", 10, "bold"),
                relief='flat',
                cursor='hand2'
            ).pack(pady=10)
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to display statistics:\n{str(e)}")
    
    def stop_simulation(self):
        """Stop the running simulation."""
        if not self.is_simulation_running:
            return
        
        if messagebox.askyesno("Stop Simulation", "Are you sure you want to stop the simulation?"):
            try:
                if self.scheduler:
                    self.scheduler.stop()
                
                self.is_simulation_running = False
                self.update_status("Stopped", "orange")
                
                self.btn_simulate.config(state=tk.NORMAL)
                self.btn_stop.config(state=tk.DISABLED)
                
                messagebox.showinfo("Info", "Simulation stopped successfully")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to stop simulation:\n{str(e)}")
    
    def update_status(self, status_text, color):
        """Update the simulation status label."""
        self.status_label.config(text=f"Status: {status_text}", fg=color)
    
    def exit_application(self):
        """Safely exit the application."""
        if self.is_simulation_running:
            if not messagebox.askyesno("Exit", "Simulation is running. Stop and exit?"):
                return
            self.stop_simulation()
        
        if messagebox.askokcancel("Exit", "Are you sure you want to exit?"):
            self.root.quit()
            self.root.destroy()
