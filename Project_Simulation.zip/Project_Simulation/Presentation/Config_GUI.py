import tkinter as tk
from tkinter import messagebox, ttk
from PIL import Image, ImageTk
import json
import os


class MatrixInputApp:
    """
    Graphical user interface for configuring warehouse layout parameters.
    Allows basic and advanced configuration and saves data persistently.
    """

    def __init__(self, root):
        # Root window configuration
        self.root = root
        self.root.title("Warehouse Configuration")
        self.root.geometry("650x800")
        self.root.configure(bg='#f0f0f0')
        
        # JSON file used for persistent configuration storage
        # JSON file used for persistent configuration storage
        script_dir = os.path.dirname(os.path.abspath(__file__))
        project_dir = os.path.dirname(script_dir)
        file_csv_dir = os.path.join(project_dir, "File_CSV")

        # Create folder if it does not exist
        os.makedirs(file_csv_dir, exist_ok=True)

        self.config_file = os.path.join(file_csv_dir, "warehouse_config.json")

        # Tkinter variables for basic configuration inputs
        self.agv_var = tk.IntVar()
        self.n_aisles_var = tk.IntVar()
        self.colums_per_shelf_var = tk.IntVar()
        self.levels_per_shelf_var = tk.IntVar()

        # Tkinter variables for advanced geometric parameters
        self.aisle_width_var = tk.DoubleVar(value=2)
        self.shelf_depth_var = tk.DoubleVar(value=0.7)
        self.shelf_height_var = tk.DoubleVar(value=1)
        self.shelf_width_var = tk.DoubleVar(value=0.7)

        # Load previously saved configuration values (if available)
        self.load_saved_values()

        # Internal attributes to store confirmed values
        self.num_agvs = None
        self.n_aisles = None
        self.colums_per_shelf = None
        self.levels_per_shelf = None
        self.aisle_width = None
        self.shelf_depth = None
        self.shelf_height = None
        self.shelf_width = None

        # Track visibility state of advanced configuration panel
        self.advanced_visible = False

        # ---------------------------------------------------
        # TITLE SECTION
        # ---------------------------------------------------
        title_frame = tk.Frame(root, bg='#2c3e50', pady=15)
        title_frame.pack(fill='x')
        tk.Label(
            title_frame,
            text="Warehouse Configuration",
            font=("Segoe UI", 16, "bold"),
            bg='#2c3e50',
            fg='white'
        ).pack()

        # ---------------------------------------------------
        # BASIC CONFIGURATION SECTION
        # ---------------------------------------------------
        basic_frame = tk.LabelFrame(
            root,
            text="Basic Configuration",
            font=("Segoe UI", 11, "bold"),
            bg='#f0f0f0',
            padx=20,
            pady=15,
            relief='groove',
            borderwidth=2
        )
        basic_frame.pack(pady=20, padx=30, fill='both')

        # Container for basic inputs and explanatory image
        basic_content = tk.Frame(basic_frame, bg='#f0f0f0')
        basic_content.pack(fill='both', expand=True)

        # Left side: input widgets
        basic_inputs = tk.Frame(basic_content, bg='#f0f0f0')
        basic_inputs.pack(side='left', fill='both', expand=True)

        # Right side: configuration image
        basic_image_frame = tk.Frame(basic_content, bg='#f0f0f0')
        basic_image_frame.pack(side='right', padx=10)

        try:
            # Load basic configuration illustration image
            script_dir = os.path.dirname(os.path.abspath(__file__))
            project_dir = os.path.dirname(script_dir)
            image_path = os.path.join(project_dir, "images", "basic_config.png")
            basic_img = Image.open(image_path)
            basic_img = basic_img.resize((200, 200), Image.Resampling.LANCZOS)
            self.basic_photo = ImageTk.PhotoImage(basic_img)
            tk.Label(
                basic_image_frame,
                image=self.basic_photo,
                bg='#f0f0f0'
            ).pack()
        except:
            # Fail silently if image cannot be loaded
            pass

        # Number of aisles input
        aisle_frame = tk.Frame(basic_inputs, bg='#f0f0f0')
        aisle_frame.pack(fill='x', pady=8)
        tk.Label(
            aisle_frame,
            text="Number of aisles:",
            font=("Segoe UI", 10),
            bg='#f0f0f0',
            width=20,
            anchor='w'
        ).pack(side='left')
        tk.Entry(
            aisle_frame,
            textvariable=self.n_aisles_var,
            font=("Segoe UI", 10),
            width=20,
            relief='solid',
            borderwidth=1
        ).pack(side='left', padx=10)

        # Columns per shelf input
        col_frame = tk.Frame(basic_inputs, bg='#f0f0f0')
        col_frame.pack(fill='x', pady=8)
        tk.Label(
            col_frame,
            text="Columns per shelf:",
            font=("Segoe UI", 10),
            bg='#f0f0f0',
            width=20,
            anchor='w'
        ).pack(side='left')
        tk.Entry(
            col_frame,
            textvariable=self.colums_per_shelf_var,
            font=("Segoe UI", 10),
            width=20,
            relief='solid',
            borderwidth=1
        ).pack(side='left', padx=10)

        # Levels per shelf input
        level_frame = tk.Frame(basic_inputs, bg='#f0f0f0')
        level_frame.pack(fill='x', pady=8)
        tk.Label(
            level_frame,
            text="Levels per shelf:",
            font=("Segoe UI", 10),
            bg='#f0f0f0',
            width=20,
            anchor='w'
        ).pack(side='left')
        tk.Entry(
            level_frame,
            textvariable=self.levels_per_shelf_var,
            font=("Segoe UI", 10),
            width=20,
            relief='solid',
            borderwidth=1
        ).pack(side='left', padx=10)

        # Number of AGVs input
        agv_frame = tk.Frame(basic_inputs, bg='#f0f0f0')
        agv_frame.pack(fill='x', pady=8)
        tk.Label(
            agv_frame,
            text="Number of AGVs:",
            font=("Segoe UI", 10),
            bg='#f0f0f0',
            width=20,
            anchor='w'
        ).pack(side='left')
        tk.Entry(
            agv_frame,
            textvariable=self.agv_var,
            font=("Segoe UI", 10),
            width=20,
            relief='solid',
            borderwidth=1
        ).pack(side='left', padx=10)

        # ---------------------------------------------------
        # ADVANCED CONFIGURATION SECTION (HIDDEN BY DEFAULT)
        # ---------------------------------------------------
        self.separator = ttk.Separator(root, orient='horizontal')

        self.advanced_container = tk.LabelFrame(
            root,
            text="Advanced Configuration",
            font=("Segoe UI", 11, "bold"),
            bg='#f0f0f0',
            padx=20,
            pady=15,
            relief='groove',
            borderwidth=2
        )

        # Container for advanced inputs and image
        advanced_content = tk.Frame(self.advanced_container, bg='#f0f0f0')
        advanced_content.pack(fill='both', expand=True)

        # Left side: advanced input fields
        self.advanced_frame = tk.Frame(advanced_content, bg='#f0f0f0')
        self.advanced_frame.pack(side='left', fill='both', expand=True)

        # Right side: advanced configuration image
        advanced_image_frame = tk.Frame(advanced_content, bg='#f0f0f0')
        advanced_image_frame.pack(side='right', padx=10)

        try:
            # Load advanced configuration illustration image
            script_dir = os.path.dirname(os.path.abspath(__file__))
            project_dir = os.path.dirname(script_dir)
            image_path = os.path.join(project_dir, "images", "advanced_config.png")
            advanced_img = Image.open(image_path)
            advanced_img = advanced_img.resize((200, 200), Image.Resampling.LANCZOS)
            self.advanced_photo = ImageTk.PhotoImage(advanced_img)
            tk.Label(
                advanced_image_frame,
                image=self.advanced_photo,
                bg='#f0f0f0'
            ).pack()
        except:
            pass

        # List of advanced parameters and associated Tk variables
        params = [
            ("Aisle Width:", self.aisle_width_var),
            ("Shelf Depth:", self.shelf_depth_var),
            ("Shelf Height:", self.shelf_height_var),
            ("Shelf Width:", self.shelf_width_var),
        ]

        for i, (label, var) in enumerate(params):
            param_frame = tk.Frame(self.advanced_frame, bg='#f0f0f0')
            param_frame.grid(row=i, column=0, sticky='ew', pady=5, padx=5)
            self.advanced_frame.grid_columnconfigure(0, weight=1)

            tk.Label(
                param_frame,
                text=label,
                font=("Segoe UI", 10),
                bg='#f0f0f0',
                width=18,
                anchor='w'
            ).pack(side='left')
            tk.Entry(
                param_frame,
                textvariable=var,
                font=("Segoe UI", 10),
                width=18,
                relief='solid',
                borderwidth=1
            ).pack(side='left', padx=10)

        # ---------------------------------------------------
        # BUTTON SECTION
        # ---------------------------------------------------
        button_section = tk.Frame(root, bg='#f0f0f0')
        button_section.pack(pady=20)

        # Confirm button
        confirm_btn = tk.Button(
            button_section,
            text="✓ Confirm",
            command=self.show_values,
            bg="#27ae60",
            fg="white",
            font=("Segoe UI", 11, "bold"),
            padx=30,
            pady=10,
            relief='flat',
            cursor='hand2'
        )
        confirm_btn.pack(pady=5)
        confirm_btn.bind('<Enter>', lambda e: confirm_btn.config(bg='#229954'))
        confirm_btn.bind('<Leave>', lambda e: confirm_btn.config(bg='#27ae60'))

        # Button to toggle advanced configuration visibility
        self.toggle_button = tk.Button(
            button_section,
            text="⚙ Show Advanced Configuration",
            command=self.toggle_advanced,
            bg="#3498db",
            fg="white",
            font=("Segoe UI", 10),
            padx=20,
            pady=8,
            relief='flat',
            cursor='hand2'
        )
        self.toggle_button.pack(pady=5)
        self.toggle_button.bind('<Enter>', lambda e: self.toggle_button.config(bg='#2980b9'))
        self.toggle_button.bind('<Leave>', lambda e: self.toggle_button.config(bg='#3498db'))

    # ---------------------------------------------------
    # ADVANCED CONFIGURATION VISIBILITY TOGGLE
    # ---------------------------------------------------
    def toggle_advanced(self):
        """Show or hide the advanced configuration panel."""
        if self.advanced_visible:
            self.separator.pack_forget()
            self.advanced_container.pack_forget()
            self.toggle_button.config(text="⚙ Show Advanced Configuration")
            self.advanced_visible = False
        else:
            self.separator.pack(fill='x', pady=10, padx=30)
            self.advanced_container.pack(pady=10, padx=30, fill='both')
            self.toggle_button.config(text="✕ Hide Advanced Configuration")
            self.advanced_visible = True

    # ---------------------------------------------------
    # LOAD / SAVE CONFIGURATION
    # ---------------------------------------------------
    def load_saved_values(self):
        """Load configuration values from the JSON file, if present."""

        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    data = json.load(f)
                    self.agv_var.set(data.get('num_agvs', 0))
                    self.n_aisles_var.set(data.get('n_aisles', 0))
                    self.colums_per_shelf_var.set(data.get('colums_per_shelf', 0))
                    self.levels_per_shelf_var.set(data.get('levels_per_shelf', 0))
                    self.aisle_width_var.set(data.get('aisle_width', 2))
                    self.shelf_depth_var.set(data.get('shelf_depth', 0.7))
                    self.shelf_height_var.set(data.get('shelf_height', 1))
                    self.shelf_width_var.set(data.get('shelf_width', 0.7))
            except (json.JSONDecodeError, KeyError):
                pass

    def save_values_to_file(self):
        """Persist the confirmed configuration values to a JSON file."""
        data = {
            'num_agvs': self.num_agvs,
            'n_aisles': self.n_aisles,
            'colums_per_shelf': self.colums_per_shelf,
            'levels_per_shelf': self.levels_per_shelf,
            'aisle_width': self.aisle_width,
            'shelf_depth': self.shelf_depth,
            'shelf_height': self.shelf_height,
            'shelf_width': self.shelf_width,
        }
        with open(self.config_file, 'w') as f:
            json.dump(data, f, indent=4)

    # ---------------------------------------------------
    # CONFIRM AND RETRIEVE VALUES
    # ---------------------------------------------------
    def show_values(self):
        """
        Validate input values, save them, and close the application.
        """
        try:
            self.num_agvs = self.agv_var.get()
            self.n_aisles = self.n_aisles_var.get()
            self.colums_per_shelf = self.colums_per_shelf_var.get()
            self.levels_per_shelf = self.levels_per_shelf_var.get()

            self.aisle_width = self.aisle_width_var.get()
            self.shelf_depth = self.shelf_depth_var.get()
            self.shelf_height = self.shelf_height_var.get()
            self.shelf_width = self.shelf_width_var.get()

            self.save_values_to_file()

            messagebox.showinfo("Success", "Values saved successfully!")
            self.root.quit()
            self.root.destroy()

        except tk.TclError:
            messagebox.showerror("Error", "Please enter valid numeric values!")

    def get_values(self):
        """Return the confirmed configuration values."""
        return {
            'num_agvs': self.num_agvs,
            'n_aisles': self.n_aisles,
            'colums_per_shelf': self.colums_per_shelf,
            'levels_per_shelf': self.levels_per_shelf,
            'aisle_width': self.aisle_width,
            'shelf_depth': self.shelf_depth,
            'shelf_height': self.shelf_height,
            'shelf_width': self.shelf_width,
        }
