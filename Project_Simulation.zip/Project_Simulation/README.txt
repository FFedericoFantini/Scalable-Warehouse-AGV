Warehouse Automation Simulation

Project Focus
This project implements a **scalable warehouse automation system** based on **Autonomous Guided Vehicles (AGVs)** operating in a structured warehouse environment.

The main focus areas of the project are:

🔁 Scalability
The entire navigation and scheduling algorithm is **warehouse-agnostic**.
- The warehouse layout is generated parametrically (aisles, shelves, levels, corridors)
- The same logic adapts automatically to:
  - Any number of aisles
  - Any shelf configuration
  - Any number of AGVs
- No hard-coded coordinates or fixed layouts are used
This makes the system easily extendable to **small, medium, and large warehouses**.



🚧 Collision Avoidance
A robust **multi-layer collision avoidance strategy** is implemented:
- Minimum distance enforcement between AGVs
- Time-based motion interpolation
- Dynamic waiting mechanism
- Path recalculation when necessary
- Edge reservation with bidirectional blocking

This guarantees safe navigation even in highly congested scenarios.


🔀 Hybrid Control Architecture
The system follows a hybrid control approach:
Centralized control
- Global order scheduling
- Task assignment
- High-level path planning
- Warehouse-wide statistics and monitoring

Decentralized control
- Local AGV collision checking
- Reactive waiting and yielding
- Independent motion execution

This hybrid model combines global optimization with local autonomy, improving both robustness and performance.


🎯 Objective
The goal of this project is to demonstrate a realistic, modular, and extensible warehouse automation framework, suitable for:
- Research
- Educational purposes
- Simulation of real industrial logistics systems


▶️ How to Run
1. Open CoppeliaSim
2. Open the file main.py
3. Run main.py
4. Configure the warehouse using the GUI
5. Wait the creation of the scene
6. Menu GUI
	- Click Visualize Graph to visualize the graph of the warehouse
	- Click Start Simulation on GUI to start simulation
	- Click Show Statistic to show statistic regarding the running simulation