# generate_graph.py
"""
Build the weighted warehouse navigation graph using all generated waypoint nodes.
"""

import csv
import math
import json


# ------------------------------------------------------------
# 2D DISTANCE (XY) — Z IS IGNORED
# ------------------------------------------------------------
def distance(p1, p2):
    return math.dist((p1[0], p1[1]), (p2[0], p2[1]))


# ------------------------------------------------------------
# CSV EXPORT
# ------------------------------------------------------------
def save_graph_to_csv(edges, filename):
    # Write edge list (with weights) to a CSV file
    with open(filename, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["node_from", "node_to", "distance"])
        for e in edges:
            w.writerow(e)


# ------------------------------------------------------------
# ADJACENCY DICTIONARY
# ------------------------------------------------------------
def edges_to_graph(edges):
    # Convert an edge list into an adjacency dictionary: graph[u][v] = weight
    graph = {}
    for u, v, d in edges:
        if u not in graph:
            graph[u] = {}
        graph[u][v] = d
    return graph


# ------------------------------------------------------------
# SAVE DICTIONARY
# ------------------------------------------------------------
def save_graph_json(graph, filename):
    # Save the adjacency dictionary to a JSON file
    with open(filename, "w") as f:
        json.dump(graph, f, indent=4)

# ------------------------------------------------------------
# WEIGHTED GRAPH CONSTRUCTION
# ------------------------------------------------------------
def build_graph(nodes):

    edges = []

    # --------------------------------------------------------
    # Group nodes by aisle (e.g., A0, A1, A2, ...)
    # --------------------------------------------------------
    aisles = {}
    for node_id, node in nodes.items():
        if node_id.startswith("A"):
            aisle = node_id.split("_")[0]   # Example: "A0"
            aisles.setdefault(aisle, []).append(node)

    aisle_numbers = sorted([int(a[1:]) for a in aisles.keys()])

    # Extract special nodes: meeting areas, spawn area, spawn exit, and shipping area
    meeting_nodes = [node for nid, node in nodes.items() if nid.startswith("MEETING_AREA")]
    spawn_area = nodes["SPAWN_AREA"]
    spawn_exit = nodes["SPAWN_EXIT"]
    shipping = nodes["SHIPPING_AREA"]

    # --------------------------------------------------------
    # 0) MEETING_AREA_i ↔ MEETING_AREA_{i+1} (vertical connection)
    # --------------------------------------------------------
    if len(meeting_nodes) > 0:
        meeting_nodes_sorted = sorted(meeting_nodes, key=lambda n: n.pos[1])  # Sort by Y

        for i in range(len(meeting_nodes_sorted) - 1):
            m1 = meeting_nodes_sorted[i]
            m2 = meeting_nodes_sorted[i+1]

            d = distance(m1.pos, m2.pos)
            edges.append((m1.id, m2.id, d))
            edges.append((m2.id, m1.id, d))

        # --------------------------------------------------------
        # 0b) SPAWN_AREA connections:
        #     - Entry from the lowest meeting area (one-way)
        #     - Exit to SPAWN_EXIT (one-way)
        # --------------------------------------------------------
        # Entry: one-way from the lowest meeting area to SPAWN_AREA
        lowest_meeting = meeting_nodes_sorted[0]  # Lowest Y (closest to spawn)
        d = distance(lowest_meeting.pos, spawn_area.pos)
        edges.append((lowest_meeting.id, spawn_area.id, d))  # One-way: meeting -> spawn

        # Exit: one-way from SPAWN_AREA to SPAWN_EXIT
        d = distance(spawn_area.pos, spawn_exit.pos)
        edges.append((spawn_area.id, spawn_exit.id, d))  
        
        # Connect meeting areas to front corridor nodes (bidirectional)
        front_corridor_nodes = [n for nid, n in nodes.items() if nid.startswith("FRONT_H_")]

        for meet in meeting_nodes:   # Contains all MEETING_AREA_i nodes
            for fc_node in front_corridor_nodes:
                d = distance(meet.pos, fc_node.pos)
                edges.append((meet.id, fc_node.id, d))
                edges.append((fc_node.id, meet.id, d))

        # Connect SPAWN_EXIT to front corridor nodes (one-way as currently implemented)
        for fc_node in front_corridor_nodes:
            d = distance(spawn_exit.pos, fc_node.pos)
            edges.append((spawn_exit.id, fc_node.id, d))
    else:
        # If no meeting areas exist, the graph cannot include the usual front-corridor entry logic
        print("⚠️ Warning: No MEETING_AREA nodes found. Graph will be limited.")
        edges.append((fc_node.id, spawn_exit.id, d))

    # --------------------------------------------------------
    # 1b) Connect FRONT CORRIDOR nodes vertically (within corridor)
    # --------------------------------------------------------
    front_h_1 = sorted([n for n in front_corridor_nodes if "_1" in n.id], key=lambda n: n.pos[1])
    front_h_2 = sorted([n for n in front_corridor_nodes if "_2" in n.id], key=lambda n: n.pos[1])

    # Connect path 1 corridor nodes (bidirectional)
    for i in range(len(front_h_1)-1):
        a = front_h_1[i]
        b = front_h_1[i+1]
        d = distance(a.pos, b.pos)
        edges.append((a.id, b.id, d))
        edges.append((b.id, a.id, d))

    # Connect path 2 corridor nodes (bidirectional)
    for i in range(len(front_h_2)-1):
        a = front_h_2[i]
        b = front_h_2[i+1]
        d = distance(a.pos, b.pos)
        edges.append((a.id, b.id, d))
        edges.append((b.id, a.id, d))

    # --------------------------------------------------------
    # 1c) FRONT CORRIDOR ↔ Ai_F1 / Ai_F2 (connections to aisle entry nodes)
    # --------------------------------------------------------
    front_meeting_nodes = []

    for a in aisle_numbers:
        # Connect FRONT_H_A{a}_1 to A{a}_F1
        fc1_id = f"FRONT_H_A{a}_1"
        f1_id = f"A{a}_F1"
        if fc1_id in nodes and f1_id in nodes:
            d = distance(nodes[fc1_id].pos, nodes[f1_id].pos)
            edges.append((fc1_id, f1_id, d))
            edges.append((f1_id, fc1_id, d))
            front_meeting_nodes.append(nodes[f1_id])

        # Connect FRONT_H_A{a}_2 to A{a}_F2
        fc2_id = f"FRONT_H_A{a}_2"
        f2_id = f"A{a}_F2"
        if fc2_id in nodes and f2_id in nodes:
            d = distance(nodes[fc2_id].pos, nodes[f2_id].pos)
            edges.append((fc2_id, f2_id, d))
            edges.append((f2_id, fc2_id, d))
            front_meeting_nodes.append(nodes[f2_id])

    # --------------------------------------------------------
    # 2) Connect Ai_F1 ↔ A(i+1)_F1 and Ai_F2 ↔ A(i+1)_F2 (vertical links)
    # --------------------------------------------------------
    # Split by path type
    front_meeting_p1 = [n for n in front_meeting_nodes if "_F1" in n.id]
    front_meeting_p2 = [n for n in front_meeting_nodes if "_F2" in n.id]

    front_meeting_p1.sort(key=lambda n: n.pos[1])
    front_meeting_p2.sort(key=lambda n: n.pos[1])

    # Connect path 1 entry nodes (bidirectional)
    for i in range(len(front_meeting_p1)-1):
        a = front_meeting_p1[i]
        b = front_meeting_p1[i+1]
        d = distance(a.pos, b.pos)
        edges.append((a.id, b.id, d))
        edges.append((b.id, a.id, d))

    # Connect path 2 entry nodes (bidirectional)
    for i in range(len(front_meeting_p2)-1):
        a = front_meeting_p2[i]
        b = front_meeting_p2[i+1]
        d = distance(a.pos, b.pos)
        edges.append((a.id, b.id, d))
        edges.append((b.id, a.id, d))

    # --------------------------------------------------------
    # 3) Connect aisle entry nodes to corridor start nodes (X0)
    # --------------------------------------------------------
    for a in aisle_numbers:
        # Path 1
        fid1 = f"A{a}_F1"
        cid1 = f"A{a}_P1_X0"
        if fid1 in nodes and cid1 in nodes:
            d = distance(nodes[fid1].pos, nodes[cid1].pos)
            edges.append((fid1, cid1, d))
            edges.append((cid1, fid1, d))

        # Path 2
        fid2 = f"A{a}_F2"
        cid2 = f"A{a}_P2_X0"
        if fid2 in nodes and cid2 in nodes:
            d = distance(nodes[fid2].pos, nodes[cid2].pos)
            edges.append((fid2, cid2, d))
            edges.append((cid2, fid2, d))

    # --------------------------------------------------------
    # 4) Build intra-aisle connections for both paths
    #    Ai_P1_Xj ↔ Ai_P1_X(j+1) and Ai_P2_Xj ↔ Ai_P2_X(j+1)
    # --------------------------------------------------------
    for a in aisle_numbers:
        # Path 1 nodes along the aisle
        path1_nodes = [n for n in aisles[f"A{a}"] if "_P1_X" in n.id]
        path1_nodes.sort(key=lambda n: n.pos[0])
        for i in range(len(path1_nodes)-1):
            c1 = path1_nodes[i]
            c2 = path1_nodes[i+1]
            d = distance(c1.pos, c2.pos)
            edges.append((c1.id, c2.id, d))
            edges.append((c2.id, c1.id, d))

        # Path 2 nodes along the aisle
        path2_nodes = [n for n in aisles[f"A{a}"] if "_P2_X" in n.id]
        path2_nodes.sort(key=lambda n: n.pos[0])
        for i in range(len(path2_nodes)-1):
            c1 = path2_nodes[i]
            c2 = path2_nodes[i+1]
            d = distance(c1.pos, c2.pos)
            edges.append((c1.id, c2.id, d))
            edges.append((c2.id, c1.id, d))

        # Cross-links between the two paths at matching X indices
        for j in range(len(path1_nodes)):
            if j < len(path2_nodes):
                p1 = path1_nodes[j]
                p2 = path2_nodes[j]
                d = distance(p1.pos, p2.pos)
                edges.append((p1.id, p2.id, d))
                edges.append((p2.id, p1.id, d))

    # --------------------------------------------------------
    # 5) Connect aisle path nodes to shelf nodes:
    #    - P1 nodes connect to Side1 shelves
    #    - P2 nodes connect to Side2 shelves
    # --------------------------------------------------------
    for node_id, node in nodes.items():
        # P1 path nodes connect only to Side1 shelf positions
        if "_P1_X" in node_id:
            aisle = node_id.split("_")[0]   # Example: A0
            x_index = int(node_id.split("_P1_X")[1])
            cnode = node

            # Connect to all Side1 shelf levels at the same X index
            for sid, snode in nodes.items():
                if sid.startswith(aisle) and f"_S1_X{x_index}_L" in sid:
                    d = distance(cnode.pos, snode.pos)
                    edges.append((cnode.id, sid, d))
                    edges.append((sid, cnode.id, d))

        # P2 path nodes connect only to Side2 shelf positions
        elif "_P2_X" in node_id:
            aisle = node_id.split("_")[0]   # Example: A0
            x_index = int(node_id.split("_P2_X")[1])
            cnode = node

            # Connect to all Side2 shelf levels at the same X index
            for sid, snode in nodes.items():
                if sid.startswith(aisle) and f"_S2_X{x_index}_L" in sid:
                    d = distance(cnode.pos, snode.pos)
                    edges.append((cnode.id, sid, d))
                    edges.append((sid, cnode.id, d))

    # --------------------------------------------------------
    # 7) Connect last aisle path nodes to front shipping nodes (both paths)
    # --------------------------------------------------------
    for a in aisle_numbers:
        # Path 1
        path1_nodes = [n for n in aisles[f"A{a}"] if "_P1_X" in n.id]
        if path1_nodes:
            path1_nodes.sort(key=lambda n: n.pos[0])
            last_p1 = path1_nodes[-1]
            fsid1 = f"A{a}_FS1"
            if fsid1 in nodes:
                d = distance(last_p1.pos, nodes[fsid1].pos)
                edges.append((last_p1.id, fsid1, d))
                edges.append((fsid1, last_p1.id, d))

        # Path 2
        path2_nodes = [n for n in aisles[f"A{a}"] if "_P2_X" in n.id]
        if path2_nodes:
            path2_nodes.sort(key=lambda n: n.pos[0])
            last_p2 = path2_nodes[-1]
            fsid2 = f"A{a}_FS2"
            if fsid2 in nodes:
                d = distance(last_p2.pos, nodes[fsid2].pos)
                edges.append((last_p2.id, fsid2, d))
                edges.append((fsid2, last_p2.id, d))

    # --------------------------------------------------------
    # 8) Connect front shipping nodes vertically (separate lines for FS1 and FS2)
    # --------------------------------------------------------
    front_ship_nodes_p1 = []
    front_ship_nodes_p2 = []

    for a in aisle_numbers:
        fsid1 = f"A{a}_FS1"
        fsid2 = f"A{a}_FS2"
        if fsid1 in nodes:
            front_ship_nodes_p1.append(nodes[fsid1])
        if fsid2 in nodes:
            front_ship_nodes_p2.append(nodes[fsid2])

    # Connect FS1 nodes vertically (bidirectional)
    front_ship_nodes_p1.sort(key=lambda n: n.pos[1])
    for i in range(len(front_ship_nodes_p1)-1):
        a = front_ship_nodes_p1[i]
        b = front_ship_nodes_p1[i+1]
        d = distance(a.pos, b.pos)
        edges.append((a.id, b.id, d))
        edges.append((b.id, a.id, d))

    # Connect FS2 nodes vertically (bidirectional)
    front_ship_nodes_p2.sort(key=lambda n: n.pos[1])
    for i in range(len(front_ship_nodes_p2)-1):
        a = front_ship_nodes_p2[i]
        b = front_ship_nodes_p2[i+1]
        d = distance(a.pos, b.pos)
        edges.append((a.id, b.id, d))
        edges.append((b.id, a.id, d))

    # --------------------------------------------------------
    # 9) BACK CORRIDOR and connections to SHIPPING_AREA
    # --------------------------------------------------------
    # Extract back corridor nodes
    back_corridor_nodes = [n for nid, n in nodes.items() if nid.startswith("BACK_H_")]

    # Connect front shipping nodes to the back corridor (bidirectional)
    for a in aisle_numbers:
        # Connect A{a}_FS1 to BACK_H_A{a}_1
        fs1_id = f"A{a}_FS1"
        bc1_id = f"BACK_H_A{a}_1"
        if fs1_id in nodes and bc1_id in nodes:
            d = distance(nodes[fs1_id].pos, nodes[bc1_id].pos)
            edges.append((fs1_id, bc1_id, d))
            edges.append((bc1_id, fs1_id, d))

        # Connect A{a}_FS2 to BACK_H_A{a}_2
        fs2_id = f"A{a}_FS2"
        bc2_id = f"BACK_H_A{a}_2"
        if fs2_id in nodes and bc2_id in nodes:
            d = distance(nodes[fs2_id].pos, nodes[bc2_id].pos)
            edges.append((fs2_id, bc2_id, d))
            edges.append((bc2_id, fs2_id, d))

    # Connect BACK CORRIDOR nodes vertically (within the corridor)
    back_h_1 = sorted([n for n in back_corridor_nodes if "_1" in n.id], key=lambda n: n.pos[1])
    back_h_2 = sorted([n for n in back_corridor_nodes if "_2" in n.id], key=lambda n: n.pos[1])

    # Connect path 1 corridor nodes (bidirectional)
    for i in range(len(back_h_1)-1):
        a = back_h_1[i]
        b = back_h_1[i+1]
        d = distance(a.pos, b.pos)
        edges.append((a.id, b.id, d))
        edges.append((b.id, a.id, d))

    # Connect path 2 corridor nodes (bidirectional)
    for i in range(len(back_h_2)-1):
        a = back_h_2[i]
        b = back_h_2[i+1]
        d = distance(a.pos, b.pos)
        edges.append((a.id, b.id, d))
        edges.append((b.id, a.id, d))

    # Connect BACK CORRIDOR nodes to the SHIPPING_AREA (bidirectional)
    for bc_node in back_corridor_nodes:
        d = distance(bc_node.pos, shipping.pos)
        edges.append((bc_node.id, "SHIPPING_AREA", d))
        edges.append(("SHIPPING_AREA", bc_node.id, d))

    return edges

