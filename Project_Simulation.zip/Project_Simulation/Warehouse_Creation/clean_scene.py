# clean_scene.py


# -------------------------------------------------------------
# Remove old objects from the scene (floors, boxes, etc.)
# -------------------------------------------------------------
DEFAULT_OBJECT_NAMES = ["Floor", "box"]


def clean(sim):
    """
    Remove previously existing default floor objects or boxes
    from the scene to avoid overlaps when regenerating the warehouse.
    """
    for handle in range(1, 100):
        try:
            alias = sim.getObjectAlias(handle)

            # Remove default objects if they exist in the scene
            if alias in DEFAULT_OBJECT_NAMES or any(name in alias for name in DEFAULT_OBJECT_NAMES):
                sim.removeObject(handle)

        except:
            # Ignore invalid handles or already removed objects
            pass
