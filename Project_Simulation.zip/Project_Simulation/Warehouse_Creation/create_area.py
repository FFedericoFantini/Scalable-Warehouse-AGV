# create_area.py
"""
Create a thin rectangular visual zone underneath a Meeting Area.
"""


def create_area_zone(sim, area, pos,
                             width=1.0, height=1.0,
                             color=[0.2, 0.2, 0.2],   # Dark gray color
                             transparency=0.15,       # Slightly transparent
                    ):
    """
    Create a thin rectangular cuboid positioned below a Meeting Area
    to visually represent a functional zone.
    """

    x, y, _ = pos

    # Position the area slightly above the floor and below the dummy
    z = 0.01

    # Create a thin cuboid representing the area
    zone = sim.createPureShape(
        0,  # Cuboid shape
        0,  # Creation options
        [width, height, 0.02],  # Very thin height
        0   # Static object
    )
    sim.setObjectInt32Param(zone, sim.shapeintparam_respondable, 1)
    sim.setObjectInt32Param(zone, sim.shapeintparam_static, 1)

    # Assign a unique name to the area
    area_name = "AREA_BASE_" + area
    sim.setObjectAlias(zone, area_name)
    sim.setObjectPosition(zone, -1, [x, y, z])

    # Apply color and transparency to the area
    sim.setShapeColor(zone, None, sim.colorcomponent_ambient_diffuse, color)
    sim.setShapeColor(zone, None, sim.colorcomponent_transparency, [transparency])

    return zone
