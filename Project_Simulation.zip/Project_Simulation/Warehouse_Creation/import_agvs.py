# import_agvs.py


def import_agvs(sim, agv_name, position, model_path):
    """
    Import an AGV by loading a .ttm model instead of creating a cuboid.
    
    :param sim: CoppeliaSim Remote API handle
    :param agv_name: Desired name for the AGV
    :param position: Initial position [x, y, z]
    :param model_path: Path to the .ttm model file
    :return: Handle of the imported AGV object
    """
    agv = sim.loadModel(model_path)
    if agv == -1:
        raise RuntimeError(f"Error loading AGV model from {model_path}")

    sim.setObjectAlias(agv, agv_name)
    sim.setObjectPosition(agv, -1, position)
    
    return agv


def import_all_agvs(sim, nodes, model_path):
    """
    Import all AGVs, one for each MEETING_AREA_i, using a .ttm model.
    """
    meeting_pts = sorted(
        [node for nid, node in nodes.items() if nid.startswith("MEETING_AREA")],
        key=lambda n: n.id
    )

    agv_handles = []

    for i, meet in enumerate(meeting_pts):
        agv_name = f"AGV_{i}"
        x, y, z = meet.pos
        pos = [x, y, z + 0.2]  # Slight vertical offset to avoid ground collision

        agv = import_agvs(sim, agv_name, pos, model_path)
        agv_handles.append(agv)

    return agv_handles
