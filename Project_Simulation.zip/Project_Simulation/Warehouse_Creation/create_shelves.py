# create_shelves.py
"""
Create shelf cuboids in CoppeliaSim based on warehouse waypoint nodes.
"""


def create_shelves_from_waypoints(sim, nodes, shelf_width, shelf_depth, shelf_height):

    for node_id, node in nodes.items():

        # Create shelves ONLY for actual shelf-level nodes
        # Example format: A3_X4_L2
        if node_id.startswith("A") and "_X" in node_id and "_L" in node_id:

            x, y, z = node.pos

            # Create a cuboid representing a single shelf level
            shelf = sim.createPureShape(
                0,                                 # Cuboid shape
                0,                                 # Creation options
                [shelf_width, shelf_depth, shelf_height],
                0                                  # Static object
            )
            sim.setObjectInt32Param(shelf, sim.shapeintparam_respondable, 0)
            sim.setObjectInt32Param(shelf, sim.shapeintparam_static, 1)
            sim.setObjectAlias(shelf, f"SHELF_{node_id}")

            # Position the shelf centered on the shelf level height
            sim.setObjectPosition(shelf, -1, [x, y, z + shelf_height / 2])

            # Apply shelf color
            sim.setShapeColor(
                shelf,
                None,
                sim.colorcomponent_ambient_diffuse,
                [0.7, 0.7, 0.7]
            )

            # Apply shelf transparency
            sim.setShapeColor(
                shelf,
                None,
                sim.colorcomponent_transparency,
                [0.3]
            )
