# generate_waypoints.py
"""
Generate all waypoint nodes for the warehouse, including shelves, aisle paths,
meeting areas, spawn areas, corridors, and the shipping area.
"""


class Node:
    def __init__(self, id, pos):
        self.id = id
        self.pos = pos


def generate_warehouse_nodes(
        n_aisles,
        coloums_per_shelf,
        levels_per_shelf,
        aisle_width,
        slot_length,
        shelf_height,
        shelf_depth,
        base_y,
        meeting_offset,
        shipping_offset,
        n_agvs,
        spacing,
        spawn_offset
    ):

    nodes = {}

    # -------------------------------------------------------
    # 1) Compute the central Y coordinate of the warehouse
    # -------------------------------------------------------
    y_center = base_y + (n_aisles * aisle_width) / 2.0

    # X-axis limits of the shelving system
    x_min = 0
    x_max = (coloums_per_shelf - 1) * slot_length

    # -------------------------------------------------------
    # 2) FRONT MEETING / SHIPPING AREAS (kept far from aisles)
    # -------------------------------------------------------
    FRONT_MARGIN = 0.5     # Margin to keep front nodes outside aisle space
    EXTRA_DISTANCE = 3.0  # Additional distance from shelves

    x_front_meet = x_min - FRONT_MARGIN
    x_front_ship = x_max + FRONT_MARGIN

    # -------------------------------------------------------
    # 3) MEETING_AREA, SPAWN_AREA, and SHIPPING_AREA creation
    # -------------------------------------------------------
    # Starting vertical shift to center meeting areas around the warehouse
    start_shift = -((n_agvs - 1) / 2) * spacing

    for i in range(n_agvs):
        y_shift = y_center + start_shift + i * spacing
        mid = f"MEETING_AREA_{i}"

        # Meeting areas placed far from the aisles
        nodes[mid] = Node(
            mid,
            (x_front_meet - meeting_offset - EXTRA_DISTANCE, y_shift, 0)
        )

    # Spawn area positioned below the lowest meeting area
    meeting_x = x_front_meet - meeting_offset - EXTRA_DISTANCE
    spawn_y = y_center + start_shift - spawn_offset
    nodes["SPAWN_AREA"] = Node(
        "SPAWN_AREA",
        (meeting_x, spawn_y, 0)
    )

    # Spawn exit positioned to the right of the spawn area
    spawn_exit_x = meeting_x + 2.0  # 2 meters to the right
    nodes["SPAWN_EXIT"] = Node(
        "SPAWN_EXIT",
        (spawn_exit_x, spawn_y, 0)
    )

    # Shipping area positioned far beyond the aisles
    nodes["SHIPPING_AREA"] = Node(
        "SHIPPING_AREA",
        (x_front_ship + shipping_offset + EXTRA_DISTANCE, y_center, 0)
    )

    # -------------------------------------------------------
    # Compute horizontal corridor X positions
    # -------------------------------------------------------
    # Front corridor: halfway between meeting areas and aisle fronts
    x_front_corridor = (
        (x_front_meet - meeting_offset - EXTRA_DISTANCE + x_front_meet) / 2.0
    )

    # Back corridor: halfway between aisle backs and shipping area
    x_back_corridor = (
        (x_front_ship + x_front_ship + shipping_offset + EXTRA_DISTANCE) / 2.0
    )

    # -------------------------------------------------------
    # 4) AISLE NODES (shelves, paths, and front/back connectors)
    # -------------------------------------------------------
    for a in range(n_aisles):

        y_shelf = base_y + a * aisle_width
        y_mid = y_shelf + aisle_width * 0.5

        # Two parallel paths inside each aisle to avoid shelf collisions
        safety_margin = 0.3  # Safety distance from shelves (meters)

        # Position paths symmetrically inside the aisle
        path_offset = (shelf_depth / 2.0) + safety_margin
        y_path1 = y_shelf + path_offset
        y_path2 = y_shelf + aisle_width - path_offset

        # Shelf rows on both sides of the aisle
        y_shelf_side1 = y_shelf
        y_shelf_side2 = y_shelf + aisle_width

        # 1️⃣ Shelf nodes (two sides, multiple levels)
        for j in range(coloums_per_shelf):
            x = j * slot_length
            for l in range(levels_per_shelf):
                z = l * shelf_height

                # Side 1 shelves (accessible from Path 1)
                nid_s1 = f"A{a}_S1_X{j}_L{l}"
                nodes[nid_s1] = Node(nid_s1, (x, y_shelf_side1, z))

                # Side 2 shelves (accessible from Path 2)
                nid_s2 = f"A{a}_S2_X{j}_L{l}"
                nodes[nid_s2] = Node(nid_s2, (x, y_shelf_side2, z))

        # 2️⃣ Aisle path nodes (two parallel paths)
        for j in range(coloums_per_shelf):
            x = j * slot_length

            nid1 = f"A{a}_P1_X{j}"
            nodes[nid1] = Node(nid1, (x, y_path1, 0))

            nid2 = f"A{a}_P2_X{j}"
            nodes[nid2] = Node(nid2, (x, y_path2, 0))

        # 4️⃣ Front aisle connection nodes (to meeting/front corridor)
        front_id1 = f"A{a}_F1"
        nodes[front_id1] = Node(front_id1, (x_front_meet, y_path1, 0))

        front_id2 = f"A{a}_F2"
        nodes[front_id2] = Node(front_id2, (x_front_meet, y_path2, 0))

        # 5️⃣ Front shipping connection nodes
        fs_id1 = f"A{a}_FS1"
        nodes[fs_id1] = Node(fs_id1, (x_front_ship, y_path1, 0))

        fs_id2 = f"A{a}_FS2"
        nodes[fs_id2] = Node(fs_id2, (x_front_ship, y_path2, 0))

    # -------------------------------------------------------
    # 5) HORIZONTAL CORRIDORS (front and back, collision-free)
    # -------------------------------------------------------
    for a in range(n_aisles):
        y_shelf = base_y + a * aisle_width
        y_mid = y_shelf + aisle_width * 0.5

        # Corridor alignment with aisle paths
        path_offset = (shelf_depth / 2.0) + 0.3
        y_path1 = y_shelf + path_offset
        y_path2 = y_shelf + aisle_width - path_offset

        # Front corridor nodes
        fc_id1 = f"FRONT_H_A{a}_1"
        nodes[fc_id1] = Node(fc_id1, (x_front_corridor, y_path1, 0))

        fc_id2 = f"FRONT_H_A{a}_2"
        nodes[fc_id2] = Node(fc_id2, (x_front_corridor, y_path2, 0))

        # Back corridor nodes
        bc_id1 = f"BACK_H_A{a}_1"
        nodes[bc_id1] = Node(bc_id1, (x_back_corridor, y_path1, 0))

        bc_id2 = f"BACK_H_A{a}_2"
        nodes[bc_id2] = Node(bc_id2, (x_back_corridor, y_path2, 0))

    return nodes
