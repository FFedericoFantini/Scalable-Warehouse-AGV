import pandas as pd
import networkx as nx
import plotly.graph_objects as go


def visualize():
    # ------------------------------------------------------------
    # 1) LOAD WAYPOINTS
    # ------------------------------------------------------------
    wp = pd.read_csv("File_CSV/waypoints.csv")
    pos = {}

    for _, row in wp.iterrows():
        node_id = row["id"]
        x = row["x"]
        y = row["y"]

        # Offset shelf nodes by level for better visual separation
        if "_S" in node_id and "_L" in node_id:
            level = int(node_id.split("_L")[1])
            x += level * 0.30

        pos[node_id] = (x, y)

    # ------------------------------------------------------------
    # 2) LOAD GRAPH
    # ------------------------------------------------------------
    edges_df = pd.read_csv("File_CSV/graph.csv")

    G = nx.DiGraph()
    for n in pos:
        G.add_node(n)

    for _, row in edges_df.iterrows():
        G.add_edge(row["node_from"], row["node_to"], weight=row["distance"])

    # ------------------------------------------------------------
    # 3) NODE COLOR ASSIGNMENT (BASED ON NAMING CONVENTION)
    # ------------------------------------------------------------
    def node_color(n):
        if n.startswith("MEETING_AREA"):
            return "green"
        if n == "SPAWN_AREA" or n == "SPAWN_EXIT":
            return "yellow"
        if n == "SHIPPING_AREA":
            return "orange"
        if "_P1_" in n or "_P2_" in n:
            return "royalblue"
        if n.startswith("FRONT_H") or n.startswith("BACK_H"):
            return "red"
        if "_S" in n and "_L" in n:
            return "gray"
        return "black"

    node_colors = [node_color(n) for n in G.nodes()]

    # ------------------------------------------------------------
    # 4) EDGE COLOR ASSIGNMENT (SEMANTIC MEANING)
    # ------------------------------------------------------------
    def edge_color(u, v):
        # Same aisle corridor (P1 or P2)
        if ("_P1_" in u and "_P1_" in v) or ("_P2_" in u and "_P2_" in v):
            return "royalblue"

        # Lateral transition between P1 and P2 at the same aisle position
        if ("_P1_" in u and "_P2_" in v) or ("_P2_" in u and "_P1_" in v):
            return "purple"

        # Shelf access connections
        if ("_S" in u and "_L" in u) or ("_S" in v and "_L" in v):
            return "gray"

        # Meeting area connections
        if u.startswith("MEETING_AREA") or v.startswith("MEETING_AREA"):
            return "green"

        # Shipping area connections
        if u == "SHIPPING_AREA" or v == "SHIPPING_AREA":
            return "orange"

        # Front or back horizontal corridors
        if u.startswith("FRONT_H") or v.startswith("FRONT_H") or \
           u.startswith("BACK_H") or v.startswith("BACK_H"):
            return "red"

        return "black"

    edges_by_color = {}

    for u, v in G.edges():
        col = edge_color(u, v)
        edges_by_color.setdefault(col, {"x": [], "y": []})

        x0, y0 = pos[u]
        x1, y1 = pos[v]

        edges_by_color[col]["x"] += [x0, x1, None]
        edges_by_color[col]["y"] += [y0, y1, None]

    edge_traces = [
        go.Scatter(
            x=coords["x"],
            y=coords["y"],
            mode="lines",
            line=dict(width=2, color=col),
            hoverinfo="none",
            showlegend=False
        )
        for col, coords in edges_by_color.items()
    ]

    # ------------------------------------------------------------
    # 5) NODE TRACE
    # ------------------------------------------------------------
    node_trace = go.Scatter(
        x=[pos[n][0] for n in G.nodes()],
        y=[pos[n][1] for n in G.nodes()],
        mode="markers",
        text=list(G.nodes()),
        hoverinfo="text",
        marker=dict(
            size=11,
            color=node_colors,
            line=dict(width=0.5, color="black")
        ),
        showlegend=False
    )

    # ------------------------------------------------------------
    # 6) LEGEND (CONSISTENT WITH GRAPH SEMANTICS)
    # ------------------------------------------------------------
    legend_items = [
        ("Meeting Area", "green"),
        ("Spawn Area / Exit", "yellow"),
        ("Shipping Area", "orange"),
        ("Aisle Corridor (P1 / P2)", "royalblue"),
        ("Lateral Switch P1 ↔ P2", "purple"),
        ("Front / Back Corridor", "red"),
        ("Shelf Node", "gray"),
    ]

    legend_traces = [
        go.Scatter(
            x=[None], y=[None],
            mode="markers",
            marker=dict(size=12, color=col),
            name=name,
            showlegend=True
        )
        for name, col in legend_items
    ]

    # ------------------------------------------------------------
    # 7) DISPLAY FIGURE
    # ------------------------------------------------------------
    fig = go.Figure(
        data=edge_traces + [node_trace] + legend_traces,
        layout=go.Layout(
            title="Warehouse Navigation Graph (Semantic Visualization)",
            hovermode="closest",
            showlegend=True,
            xaxis=dict(showgrid=True, zeroline=False),
            yaxis=dict(showgrid=True, zeroline=False),
            width=1300,
            height=900
        )
    )

    fig.show()
